package UT3Prácticadeclase;
import java.util.Scanner;

public class Ej3 {

		//Cálculo de números primos
		
		 public static void main(String[] args) {
			 int limite;
			 Scanner entrada = new Scanner(System.in);
			 System.out.println("Introduce un valor entero: ");

			 limite = entrada.nextInt();
			 entrada.close();
			 
			 for(int i = 1; i <= limite; i++) {
				 
				 int contadorDiv = 0;
				 
				 for(int j = 1; j <= i; j++) {
					 if(i % j == 0) {
					 contadorDiv++;
					 }
				 }
				 	if(contadorDiv == 2) {
						 System.out.println(i);
				 	}
			 }
		 }
