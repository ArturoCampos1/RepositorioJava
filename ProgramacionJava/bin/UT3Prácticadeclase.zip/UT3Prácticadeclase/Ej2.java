package UT3Prácticadeclase;
import java.util.Scanner;

public class Ej2 {
     public static void main(String args[]) {
         Scanner entrada = new Scanner(System.in);
         String num = entrada.nextLine();
         
         int contador = 1;
         
         for (int i= 0; i <4; i++) {
             num.charAt(i);
             System.out.println("La cifra "+ contador +" es "+ num.charAt(i));
             contador ++;
         }
        
         entrada.close();
        
     }

}