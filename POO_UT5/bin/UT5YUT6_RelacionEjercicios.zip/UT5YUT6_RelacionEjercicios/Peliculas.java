package UT5YUT6_RelacionEjercicios;

import java.util.*;

public class Peliculas {

    private String titulo;
    private String director;
    private String genero;
    private String actores;
    private int minutos;
    private String resumen;

    public Peliculas(String titulo, String director, String genero, String actores, int minutos, String resumen) {
        this.titulo = titulo;
        this.director = director;
        this.genero = genero;
        this.actores = actores;
        this.minutos = minutos;
        this.resumen = resumen;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getActores() {
        return actores;
    }

    public void setActores(String actores) {
        this.actores = actores;
    }

    public int getMinutos() {
        return minutos;
    }

    public void setMinutos(int minutos) {
        this.minutos = minutos;
    }

    public String getResumen() {
        return resumen;
    }

    public void setResumen(String resumen) {
        this.resumen = resumen;
    }

    public static Peliculas generarObjeto(String a, String b, String c, String d, int e, String f) {
        Peliculas pelicula = new Peliculas(a, b, c, d, e, f);
        System.out.println("Película registrada con éxito.");
        return pelicula;
    }

    public static void muestraDVDCine(String nombre, ArrayList<Peliculas> p) {
        boolean encontrada = false;
        for (Peliculas pelicula : p) {
            if (pelicula.getTitulo().equalsIgnoreCase(nombre)) { // Compara ignorando mayúsculas
                System.out.println("\nTítulo: " + pelicula.getTitulo());
                System.out.println("Director: " + pelicula.getDirector());
                System.out.println("Género: " + pelicula.getGenero());
                System.out.println("Actor destacado: " + pelicula.getActores());
                System.out.println("Duración: " + pelicula.getMinutos() + " minutos");
                System.out.println("Resumen: " + pelicula.getResumen());
                encontrada = true;
                break;
            }
        }
        if (!encontrada) {
            System.out.println("No se encontró ninguna película con el título: " + nombre);
        }
    }
    
    public static boolean esThriller(String a, ArrayList<Peliculas> p) {
    	for (Peliculas pelicula: p) {
    		if(pelicula.getTitulo().equalsIgnoreCase(a) && pelicula.getGenero().equalsIgnoreCase("Thriller")) {
    			return true;
    		}
       	}
    	return false;
    }
    
    public static String tieneResumen(String a, ArrayList<Peliculas> p) {
    	for (Peliculas pelicula: p) {
    		if(pelicula.getTitulo().equalsIgnoreCase(a) && pelicula.resumen.equalsIgnoreCase("")) {
    			return "La película " + a + " no tiene resumen registrado";
    		}
    	}
    	return "La película " + a + " tiene resumen";
    }
    
    public static void mostrarDuracion(String a, ArrayList<Peliculas> p) {
    	for (Peliculas pelicula: p) {
    		if(pelicula.getTitulo().equalsIgnoreCase(a)) {
    			System.out.println(pelicula.getMinutos() + " min");
    		}
    	}
    }
    
    public static void main(String[] args) {
        ArrayList<Peliculas> peliculas = new ArrayList<>();
        String nombre;
        Scanner sc = new Scanner(System.in);
        boolean verificar = true;

        while (verificar) {
            System.out.println("\n¿Qué quieres hacer?");
            System.out.println("1.- Ingresar película");
            System.out.println("2.- Mostrar datos de la película");
            System.out.println("3.- ¿Es thriller?");
            System.out.println("4.- ¿Tiene resumen?");
            System.out.println("5.- Mostrar duración");
            System.out.println("6.- Salir");
            System.out.print("Input: ");
            int a = sc.nextInt();
            sc.nextLine(); // Consumir salto de línea

            switch (a) {
                case 1:
                    System.out.print("Ingresa el título: ");
                    String titulo = sc.nextLine();
                    System.out.print("Ingresa el director: ");
                    String director = sc.nextLine();
                    System.out.print("Ingresa el género: ");
                    String genero = sc.nextLine();
                    System.out.print("Ingresa un actor destacado: ");
                    String actor = sc.nextLine();
                    System.out.print("Ingresa la duración en minutos: ");
                    int minutos = sc.nextInt();
                    sc.nextLine(); // Consumir salto de línea
                    System.out.print("Resume la película (si no lo desea dejelo en blanco): ");
                    String resumen = sc.nextLine();

                    Peliculas peli = generarObjeto(titulo, director, genero, actor, minutos, resumen);
                    peliculas.add(peli);
                    break;

                case 2:
                    System.out.println("Ingresa el nombre de la película:");
                    nombre = sc.nextLine();
                    muestraDVDCine(nombre, peliculas);
                    break;

                case 3:
                    System.out.println("Ingresa el nombre de la película:");
                    nombre = sc.nextLine();
                    System.out.println(esThriller(nombre, peliculas));
                    break;
                    
                case 4:
                    System.out.println("Ingresa el nombre de la película:");
                    nombre = sc.nextLine();
                    System.out.println(tieneResumen(nombre, peliculas));
                    break;
                    
                case 5:
                    System.out.println("Ingresa el nombre de la película:");
                    nombre = sc.nextLine();
                    mostrarDuracion(nombre, peliculas);
                    break;
                    
                case 6:
                    System.out.println("Saliendo...");
                    verificar = false;
                    break;

                default:
                    System.out.println("Número no válido");
                    break;
            }
        }
        sc.close();
    }
}
