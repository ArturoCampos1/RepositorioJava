package UT5YUT6_RelacionEjercicios;

public class testRestaurante {
    public static void main(String[] args) {
        Restaurante restaurante = new Restaurante(10, 5);

        restaurante.showPapas();
        restaurante.showChocos();
        System.out.println("Clientes que se pueden atender: " + restaurante.getComensales());

        restaurante.addPapas(5);
        restaurante.addChocos(3);

        restaurante.showPapas();
        restaurante.showChocos();
        System.out.println("Clientes que se pueden atender: " + restaurante.getComensales());
    }
}
