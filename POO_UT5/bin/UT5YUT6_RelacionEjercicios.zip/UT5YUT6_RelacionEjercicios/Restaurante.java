package UT5YUT6_RelacionEjercicios;

public class Restaurante {
    private double kilosPapas;
    private double kilosChocos;

    public Restaurante(double kilosPapas, double kilosChocos) {
        this.kilosPapas = kilosPapas;
        this.kilosChocos = kilosChocos;
    }

    public void addChocos(int x) {
        kilosChocos += x;
    }

    public void addPapas(int x) {
        kilosPapas += x;
    }

    public int getComensales() {
        int porPapas = (int) (kilosPapas * 3);
        int porChocos = (int) (kilosChocos * 6);
        return Math.min(porPapas, porChocos);
    }

    public void showChocos() {
        System.out.println("Kilos de chocos en almacén: " + kilosChocos);
    }

    public void showPapas() {
        System.out.println("Kilos de papas en almacén: " + kilosPapas);
    }
}
