package UT5YUT6_RelacionEjercicios;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Alumno alumno1 = new Alumno("Arturo", 18);
		Alumno alumno2 = new Alumno("Sergio", 19);
		Alumno alumno3 = new Alumno("Enrique", 19);
		
		alumno1.agregarAsignatura("Lenguaje de Marcas", 7);
		alumno2.agregarAsignatura("Sotenibilidad", 9);
		alumno3.agregarAsignatura("Sistemas informáticos", 4);
		
		//Mostramos los datos de los alumnos 
		System.out.println(alumno1.devolverDatos());
		alumno1.devolverAsignaturas();
		
		System.out.println("-------------------------");
		
		System.out.println(alumno2.devolverDatos());
		alumno2.devolverAsignaturas();
		
		System.out.println("-------------------------");

		
		System.out.println(alumno3.devolverDatos());
		alumno3.devolverAsignaturas();
	}
	
}
