package UT5YUT6_RelacionEjercicios;

public class Personaje16 {
    protected String nombre;
    protected int energia;

    public Personaje16(String nombre, int energia) {
        this.nombre = nombre;
        this.energia = energia;
    }

    public void alimentarse(int cantidad) {
        energia += cantidad;
    }

    public int getEnergia() {
        return energia;
    }

    public String getNombre() {
        return nombre;
    }
}
