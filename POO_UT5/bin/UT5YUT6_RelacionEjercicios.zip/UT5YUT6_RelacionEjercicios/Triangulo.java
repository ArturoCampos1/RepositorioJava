package UT5YUT6_RelacionEjercicios;

public class Triangulo {
	double long_lado1;
	double long_lado2;
	double long_lado3;

	public Triangulo(double long_lado1, double long_lado2, double long_lado3) {
		super();
		this.long_lado1 = long_lado1;
		this.long_lado2 = long_lado2;
		this.long_lado3 = long_lado3;
	}

	public static boolean compareTo_Triangulos(Triangulo a, Triangulo b) {
		if (a.long_lado1 == b.long_lado1 && a.long_lado2 == b.long_lado2 && a.long_lado3 == b.long_lado3) {
			return true;
		}
		return false;
	}

	public static boolean compareTo_VTriangulos(Triangulo v[]) {
	    for (int i = 0; i < v.length - 1; i++) {
	        for (int j = i + 1; j < v.length; j++) {
	            if (v[i].long_lado1 == v[j].long_lado1 &&
	                v[i].long_lado2 == v[j].long_lado2 &&
	                v[i].long_lado3 == v[j].long_lado3) {
	                return true;
	            }
	        }
	    }
	    return false;
	}

	public int tipo_Triangulo() {
		if (long_lado1 == long_lado2 && long_lado1 == long_lado3) {
			return 1;
		}
		if (long_lado1 == long_lado2 || long_lado2 == long_lado3 || long_lado1 == long_lado3) {
			return 2;
		}
		if (long_lado1 != long_lado2 && long_lado2 != long_lado3 && long_lado1 != long_lado3) {
			return 3;
		}
		return 0;
	}

	public static void main(String[] args) {
		Triangulo t1 = new Triangulo(4, 1, 3);
		Triangulo t2 = new Triangulo(4, 1, 9);
		Triangulo t3 = new Triangulo(2, 1, 7);
		Triangulo[] t = new Triangulo[3];
		
		t[0] = t1;
		t[1] = t2;
		t[2] = t3;

		System.out.println(compareTo_Triangulos(t1, t2));
		System.out.println(compareTo_VTriangulos(t));
		System.out.println(t1.tipo_Triangulo());
	}

}
