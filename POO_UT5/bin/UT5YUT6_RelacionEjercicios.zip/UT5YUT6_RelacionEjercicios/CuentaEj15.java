package UT5YUT6_RelacionEjercicios;

public class CuentaEj15 {
    private float saldo;

    public CuentaEj15() {
        this.saldo = 0;
    }

    public CuentaEj15(float saldoInicial) {
        this.saldo = saldoInicial;
    }

    public void ingresar(float c) {
        saldo += c;
    }

    public void extraer(float c) {
        saldo -= c;
    }

    public float getSaldo() {
        return saldo;
    }
}
