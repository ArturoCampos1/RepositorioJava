package UT5YUT6_RelacionEjercicios;

public class Empleado implements Cloneable {
	private String nif;
	private double sueldoBase;
	private double pagoPorHoraExtra;
	private int horasExtraRealizadas;
	private double tipoIRPF;
	private boolean casado;
	private int numeroHijos;

	// Constructor
	public Empleado(String nif, double sueldoBase, double pagoPorHoraExtra, int horasExtraRealizadas, double tipoIRPF,
			boolean casado, int numeroHijos) {
		this.nif = nif;
		this.sueldoBase = sueldoBase;
		this.pagoPorHoraExtra = pagoPorHoraExtra;
		this.horasExtraRealizadas = horasExtraRealizadas;
		this.tipoIRPF = tipoIRPF;
		this.casado = casado;
		this.numeroHijos = numeroHijos;
	}

	// Getters y Setters
	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	public double getSueldoBase() {
		return sueldoBase;
	}

	public void setSueldoBase(double sueldoBase) {
		this.sueldoBase = sueldoBase;
	}

	public double getPagoPorHoraExtra() {
		return pagoPorHoraExtra;
	}

	public void setPagoPorHoraExtra(double pagoPorHoraExtra) {
		this.pagoPorHoraExtra = pagoPorHoraExtra;
	}

	public int getHorasExtraRealizadas() {
		return horasExtraRealizadas;
	}

	public void setHorasExtraRealizadas(int horasExtraRealizadas) {
		this.horasExtraRealizadas = horasExtraRealizadas;
	}

	public double getTipoIRPF() {
		return tipoIRPF;
	}

	public void setTipoIRPF(double tipoIRPF) {
		this.tipoIRPF = tipoIRPF;
	}

	public boolean isCasado() {
		return casado;
	}

	public void setCasado(boolean casado) {
		this.casado = casado;
	}

	public int getNumeroHijos() {
		return numeroHijos;
	}

	public void setNumeroHijos(int numeroHijos) {
		this.numeroHijos = numeroHijos;
	}

	// Cálculo del complemento por horas extra
	public double calcularComplementoHorasExtra() {
		return horasExtraRealizadas * pagoPorHoraExtra;
	}

	// Cálculo del sueldo bruto
	public double calcularSueldoBruto() {
		return sueldoBase + calcularComplementoHorasExtra();
	}

	// Cálculo de la retención de IRPF
	public double calcularRetencionIRPF() {
		double porcentajeRetencion = tipoIRPF;
		if (casado) {
			porcentajeRetencion -= 2; 
		}
		porcentajeRetencion -= numeroHijos; 
		double sueldoBruto = calcularSueldoBruto();
		return sueldoBruto * porcentajeRetencion / 100;
	}

	// Cálculo del sueldo neto
	public double calcularSueldoNeto() {
		return calcularSueldoBruto() - calcularRetencionIRPF();
	}

	// Visualización de la información básica del empleado
	public void println() {
		System.out.println("NIF: " + nif);
		System.out.println("Sueldo Base: " + sueldoBase);
	}

	// Visualización de toda la información del empleado
	public void printAll() {
		println();
		System.out.println("Pago por Hora Extra: " + pagoPorHoraExtra);
		System.out.println("Horas Extra Realizadas: " + horasExtraRealizadas);
		System.out.println("Tipo IRPF: " + tipoIRPF);
		System.out.println("Casado: " + (casado ? "Sí" : "No"));
		System.out.println("Número de Hijos: " + numeroHijos);
		System.out.println("Complemento por Horas Extra: " + calcularComplementoHorasExtra());
		System.out.println("Sueldo Bruto: " + calcularSueldoBruto());
		System.out.println("Retención IRPF: " + calcularRetencionIRPF());
		System.out.println("Sueldo Neto: " + calcularSueldoNeto());
	}

	// Método para clonar un objeto Empleado
	@Override
	public Empleado clone() {
		try {
			return (Empleado) super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
			return null;
		}
	}
	    public static void main(String[] args) {
	        // Crear un objeto Empleado con algunos datos de ejemplo
	        Empleado empleado = new Empleado("12345678A", 1500, 20, 10, 15, true, 2);

	        // Mostrar la información básica del empleado
	        System.out.println("Informacion Basica del Empleado:");
	        empleado.println();
	        System.out.println("-------------------------------");

	        // Mostrar toda la información detallada del empleado
	        System.out.println("Informacion Completa del Empleado:");
	        empleado.printAll();
	        System.out.println("-------------------------------");

	        // Mostrar el complemento por horas extra
	        System.out.println("Complemento por Horas Extra: " + empleado.calcularComplementoHorasExtra());
	        System.out.println("-------------------------------");

	        // Mostrar el sueldo bruto
	        System.out.println("Sueldo Bruto: " + empleado.calcularSueldoBruto());
	        System.out.println("-------------------------------");

	        // Mostrar la retención IRPF
	        System.out.println("Retencion IRPF: " + empleado.calcularRetencionIRPF());
	        System.out.println("-------------------------------");

	        // Mostrar el sueldo neto
	        System.out.println("Sueldo Neto: " + empleado.calcularSueldoNeto());
	        System.out.println("-------------------------------");

	        // Clonación del objeto empleado
	        System.out.println("Clonación del Empleado:");
	        Empleado empleadoClon = empleado.clone();
	        if (empleadoClon != null) {
	            empleadoClon.println();
	        }
	}

}
