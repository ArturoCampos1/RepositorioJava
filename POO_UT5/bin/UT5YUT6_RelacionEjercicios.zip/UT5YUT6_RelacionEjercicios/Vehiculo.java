package UT5YUT6_RelacionEjercicios;

public class Vehiculo {

	private String modelo;
	private double potencia;
	private boolean cRuedas;
	
	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public double getPotencia() {
		return potencia;
	}

	public void setPotencia(double potencia) {
		this.potencia = potencia;
	}

	public boolean iscRuedas() {
		return cRuedas;
	}

	public void setcRuedas(boolean cRuedas) {
		this.cRuedas = cRuedas;
	}

	public Vehiculo(String modelo) {
		this.modelo = modelo;
	}

	public String imprimir() {
        return "Datos: " +
        		"\nModelo: " + modelo + "\n" +
                "Potencia: " + potencia + " CV\n" +
                "Tracción a las cuatro ruedas: " + (cRuedas ? "Sí" : "No"); 
	}
	
	public static void main(String[] args) {
		
        Vehiculo vehiculoPrueba = new Vehiculo("Toyota Corolla");
        vehiculoPrueba.setPotencia(135.5);
        vehiculoPrueba.setcRuedas(true);
        
        System.out.println(vehiculoPrueba.imprimir());

	}
	
}
