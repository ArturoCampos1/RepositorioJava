package UT5YUT6_RelacionEjercicios;

import java.util.ArrayList;

public class Alumno {

	ArrayList<Asignatura> asignatura;
	private String nombre;
	private int edad;

	public Alumno(String nombre, int edad) {
		this.nombre = nombre;
		this.edad = edad;
		this.asignatura = new ArrayList<>();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	

	public int consultarEdad() {
		return edad;
	}

	public void modificarEdad(int edad) {
		this.edad = edad;
	}
	
    public void agregarAsignatura(String nombre, int nota) {
        asignatura.add(new Asignatura(nombre, nota));
    }

    public String devolverDatos() {
        return "Nombre del alumno: " + nombre + 
               "\nEdad: " + edad + 
               "\nAsignaturas que cursó:";
    }

	
    public void devolverAsignaturas() {
    	for (Asignatura a: asignatura) {
    		System.out.println("-" + a.mostrarAsignatura() + "\n-" + a.getNota() + "\n-" + a.correccion());
    	}
    }
    
}
