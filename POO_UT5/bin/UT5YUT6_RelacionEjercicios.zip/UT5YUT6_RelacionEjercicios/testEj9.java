package UT5YUT6_RelacionEjercicios;

public class testEj9 {
	public static void main(String[] args) {
        Direccion dir1 = new Direccion("Av. Principal", 123, 2, "Madrid");
        Direccion dir2 = new Direccion("Calle Mayor", 456, 3, "Barcelona");
        Direccion dir3 = new Direccion("Gran Vía", 789, 5, "Valencia");

        EmpleadoEj9 emp1 = new EmpleadoEj9("Juan Pérez", 3000, dir1);
        EmpleadoEj9 emp2 = new EmpleadoEj9("María Gómez", 3500, dir2);
        EmpleadoEj9 emp3 = new EmpleadoEj9("Carlos Ruiz", 2800, dir3);

        emp1.mostrarDatos();
        emp2.mostrarDatos();
        emp3.mostrarDatos();
    }
}
