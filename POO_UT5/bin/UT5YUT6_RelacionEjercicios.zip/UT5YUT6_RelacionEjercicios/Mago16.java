package UT5YUT6_RelacionEjercicios;

public class Mago16 extends Personaje16 {
    private String poder;

    public Mago16(String nombre, String poder) {
        super(nombre, 100);
        this.poder = poder;
    }

    public String encantar() {
        if (energia >= 2) {
            energia -= 2;
            return poder;
        } else {
            return "No tienes suficiente energía para encantar.";
        }
    }

    public String getPoder() {
        return poder;
    }
}

