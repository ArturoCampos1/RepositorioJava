package UT5YUT6_RelacionEjercicios;

public class Cafetera {

    private int capacidadMaxima;
    private int cantidadActual;
    
    // Constructor predeterminado
    public Cafetera() {
        this.capacidadMaxima = 1000;
        this.cantidadActual = 0;
    }

    // Constructor con capacidad máxima
    public Cafetera(int capacidadMaxima) {
        this.capacidadMaxima = capacidadMaxima;
        this.cantidadActual = capacidadMaxima;
    }

    // Constructor con capacidad máxima y cantidad actual
    public Cafetera(int capacidadMaxima, int cantidadActual) {
        this.capacidadMaxima = capacidadMaxima;
        if (cantidadActual > capacidadMaxima) {
            this.cantidadActual = capacidadMaxima;  
        } else {
            this.cantidadActual = cantidadActual;
        }
    }

    public int getCapacidadMaxima() {
        return capacidadMaxima;
    }

    public void setCapacidadMaxima(int capacidadMaxima) {
        this.capacidadMaxima = capacidadMaxima;
    }

    public int getCantidadActual() {
        return cantidadActual;
    }

    public void setCantidadActual(int cantidadActual) {
        if (cantidadActual > capacidadMaxima) {
            this.cantidadActual = capacidadMaxima;
        } else {
            this.cantidadActual = cantidadActual;
        }
    }

    // Llenar cafetera
    public void llenarCafetera() {
        this.cantidadActual = capacidadMaxima;
    }

    // Servir cafe
    public int servirTaza(int cantidadTaza) {
        int servido;
        if (cantidadTaza > cantidadActual) {
            servido = cantidadActual;  
            cantidadActual = 0;         
        } else {
            servido = cantidadTaza;     
            cantidadActual -= cantidadTaza;  
        }
        return servido;
    }

    // Vaciar cafetera
    public void vaciarCafetera() {
        cantidadActual = 0;  
    }

    // Meter cafe
    public void agregarCafe(int cantidadCafe) {
        if (cantidadActual + cantidadCafe > capacidadMaxima) {
            cantidadActual = capacidadMaxima; 
        } else {
            cantidadActual += cantidadCafe;  
        }
    }

   
    public void mostrarEstado() {
        System.out.println("\nCapacidad máxima: " + capacidadMaxima + " cc");
        System.out.println("Cantidad actual: " + cantidadActual + " cc");
    }

 
    public static void main(String[] args) {
        // Crear una cafetera con el constructor predeterminado
        Cafetera cafetera1 = new Cafetera();
        cafetera1.mostrarEstado();

        // Crear una cafetera con capacidad máxima de 1500 cc
        Cafetera cafetera2 = new Cafetera(1500);
        cafetera2.mostrarEstado();

        // Crear una cafetera con capacidad máxima de 1500 cc y 1200 cc de café
        Cafetera cafetera3 = new Cafetera(1500, 1200);
        cafetera3.mostrarEstado();

        // Llenar la cafetera1
        cafetera1.llenarCafetera();
        cafetera1.mostrarEstado();

        // Servir una taza de 500 cc
        int servido = cafetera1.servirTaza(500);
        System.out.println("Se sirvieron " + servido + " cc de café.");
        cafetera1.mostrarEstado();

        // Agregar 300 cc de café a la cafetera1
        cafetera1.agregarCafe(300);
        cafetera1.mostrarEstado();

        // Vaciar la cafetera1
        cafetera1.vaciarCafetera();
        cafetera1.mostrarEstado();
    }
}
