package UT5YUT6_RelacionEjercicios;

public class Ej12 {
    private String nombre;
    private double horasTrabajadas;
    private double tarifa;

    public Ej12(String nombre, double horasTrabajadas, double tarifa) {
        this.nombre = nombre;
        this.horasTrabajadas = horasTrabajadas;
        this.tarifa = tarifa;
    }


    public double calcularSueldoBruto() {
        if (horasTrabajadas <= 40) {
            return horasTrabajadas * tarifa;
        } else {
            double horasExtras = horasTrabajadas - 40;
            return (40 * tarifa) + (horasExtras * tarifa * 1.5);
        }
    }
    
    public String getNombre() {
        return nombre;
    }
    
    public double getHorasTrabajadas() {
        return horasTrabajadas;
    }
    
    public double getTarifa() {
        return tarifa;
    }
}
