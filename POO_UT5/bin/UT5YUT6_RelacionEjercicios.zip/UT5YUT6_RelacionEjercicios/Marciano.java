package UT5YUT6_RelacionEjercicios;

public class Marciano {
    private boolean vivo = false;  // Valor por defecto: false
    private String nombre;
    
    private static int numMarcianos = 0;
    
    public Marciano(String nombre) {
        this.nombre = nombre;
        this.vivo = true;
        numMarcianos++;
        nace();
    }
    
    private void nace() {
        System.out.println("Hola, he nacido y soy el marciano " + nombre + ". Marcianos vivos: " + numMarcianos);
    }
    
    public void muere() {
        if (vivo) {
            vivo = false;
            numMarcianos--;
            System.out.println("El marciano " + nombre + " ha muerto");
        } else {
            System.out.println("El marciano " + nombre + " ya está muerto");
        }
    }
    
    public boolean estaVivo() {
        return vivo;
    }
    
    public static int cuentaMarcianos() {
        return numMarcianos;
    }
    
    public String toString() {
        return "Marciano " + nombre + " - " + (vivo ? "Vivo" : "Muerto");
    }
}
