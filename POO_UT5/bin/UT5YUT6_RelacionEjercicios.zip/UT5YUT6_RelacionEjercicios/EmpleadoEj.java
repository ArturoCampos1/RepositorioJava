package UT5YUT6_RelacionEjercicios;

public class EmpleadoEj extends Persona {
    private double sueldo;

    public EmpleadoEj(String nombre, int edad, double sueldo) {
        super(nombre, edad);
        this.sueldo = sueldo;
    }

    public void cargarSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public void imprimirSueldo() {
        System.out.println("Sueldo: " + sueldo);
    }

    public void imprimirDatosEmpleado() {
        imprimirDatos();
        imprimirSueldo();
    }

    public static void main(String[] args) {
        Persona arturo = new Persona("Arturo", 18);

        System.out.println("Datos de la Persona:");
        arturo.imprimirDatos();
        System.out.println("----------------------------");

        EmpleadoEj Juan = new EmpleadoEj("Juan", 60, 1500);

        System.out.println("Datos del Empleado:");
        Juan.imprimirDatosEmpleado();
    }
}
