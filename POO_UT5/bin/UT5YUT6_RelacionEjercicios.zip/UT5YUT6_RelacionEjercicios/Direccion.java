package UT5YUT6_RelacionEjercicios;

public class Direccion {
	 	String calle;
	    int numero;
	    int piso;
	    String ciudad;

	    public Direccion(String calle, int numero, int piso, String ciudad) {
	        this.calle = calle;
	        this.numero = numero;
	        this.piso = piso;
	        this.ciudad = ciudad;
	    }
}
