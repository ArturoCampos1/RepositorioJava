package UT5YUT6_RelacionEjercicios;

import java.util.Scanner;

public class MainGestionPlaza {
    public static void main(String[] args) {
        PlazaAparcamiento plaza = new PlazaAparcamiento(1);
        Scanner scanner = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("PLAZA APARCAMIENTO");
            System.out.println("1. Aparcar coche");
            System.out.println("2. Sacar coche");
            System.out.println("3. Ver coche aparcado");
            System.out.println("4. Salir aplicacion");
            System.out.print("OPCION: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    plaza.aparcarCoche();
                    break;
                case 2:
                    plaza.sacarCoche();
                    break;
                case 3:
                    plaza.verCocheAparcado();
                    break;
                case 4:
                    System.out.println("Estado final de la plaza:");
                    plaza.mostrarAtributos();
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        } while (opcion != 4);

        scanner.close();
    }
}