package UT5YUT6_RelacionEjercicios;

import java.util.Scanner;

public class TestEj12 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Ej12[] empleados = new Ej12[3];

        for (int i = 0; i < empleados.length; i++) {
            System.out.println("Ingrese el nombre del empleado " + (i + 1) + ":");
            String nombre = sc.nextLine();
            
            System.out.println("Ingrese el número de horas trabajadas del empleado " + (i + 1) + ":");
            double horas = sc.nextDouble();
            
            System.out.println("Ingrese la tarifa por hora del empleado " + (i + 1) + ":");
            double tarifa = sc.nextDouble();
            sc.nextLine(); 

            empleados[i] = new Ej12(nombre, horas, tarifa);
        }
        
        System.out.println("\n--- Sueldos Brutos de los Empleados ---");
        for (Ej12 emp : empleados) {
            double sueldoBruto = emp.calcularSueldoBruto();
            System.out.println(emp.getNombre() + " trabajó " + emp.getHorasTrabajadas() +
                " horas, cobra " + emp.getTarifa() + " euros la hora, por lo que su sueldo bruto es de " +
                sueldoBruto + " euros.");
        }
        
        sc.close();
    }
}
