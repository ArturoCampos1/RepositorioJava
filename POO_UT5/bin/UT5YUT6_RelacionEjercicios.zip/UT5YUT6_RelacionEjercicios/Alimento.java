package UT5YUT6_RelacionEjercicios;

public class Alimento {
    private String nombre;
    private double porcentajeLipidios;
    private double porcentajeHidratos;
    private double porcentajeProteinas;
    private boolean origenAnimal;
    private char vitaminas;
    private char minerales;

    public Alimento(String nombre) {
        this.nombre = nombre;
        this.porcentajeLipidios = 0;
        this.porcentajeHidratos = 0;
        this.porcentajeProteinas = 0;
        this.origenAnimal = false;
        this.vitaminas = 'B';  
        this.minerales = 'B';  
    }

    public Alimento(String nombre, double porcentajeLipidios, double porcentajeHidratos,
                    double porcentajeProteinas, boolean origenAnimal, char vitaminas, char minerales) {
        this.nombre = nombre;
        this.porcentajeLipidios = porcentajeLipidios;
        this.porcentajeHidratos = porcentajeHidratos;
        this.porcentajeProteinas = porcentajeProteinas;
        this.origenAnimal = origenAnimal;
        this.vitaminas = vitaminas;
        this.minerales = minerales;
    }


    public boolean esDietetico() {
        return (porcentajeLipidios < 20) && (vitaminas != 'B');
    }

    public String muestraAlimento() {
        return "Nombre: " + nombre + "\n" +
               "Contenido en lípidos: " + porcentajeLipidios + "%\n" +
               "Contenido en hidratos de carbono: " + porcentajeHidratos + "%\n" +
               "Contenido en proteínas: " + porcentajeProteinas + "%\n" +
               "Origen animal: " + (origenAnimal ? "Sí" : "No") + "\n" +
               "Contenido en vitaminas: " + vitaminas + "\n" +
               "Contenido en minerales: " + minerales;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPorcentajeLipidios() {
        return porcentajeLipidios;
    }

    public double getPorcentajeHidratos() {
        return porcentajeHidratos;
    }

    public double getPorcentajeProteinas() {
        return porcentajeProteinas;
    }

    public boolean isOrigenAnimal() {
        return origenAnimal;
    }

    public char getVitaminas() {
        return vitaminas;
    }

    public char getMinerales() {
        return minerales;
    }
    
    public static void main(String[] args) {
    	Alimento patata = new Alimento("Patata", 10.8, 15, 5.3, true, 'A', 'C' );
    
    	System.out.println(patata.esDietetico());
    	System.out.println(patata.muestraAlimento());
    } 
    
}
