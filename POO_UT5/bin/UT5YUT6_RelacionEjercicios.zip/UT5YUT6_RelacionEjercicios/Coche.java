package UT5YUT6_RelacionEjercicios;

import java.util.Scanner;

class Coche {
    private String matricula;
    private String marca;
    private String modelo;

    public Coche(String matricula, String marca, String modelo) {
        this.matricula = matricula;
        this.marca = marca;
        this.modelo = modelo;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public void mostrarAtributos() {
        System.out.println("Matricula: " + matricula);
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
    }
}

class PlazaAparcamiento {
    private int numeroPlaza;
    private Coche coche;
    private boolean disponible;
    private int cochesAparcados;

    public PlazaAparcamiento(int numeroPlaza) {
        this.numeroPlaza = numeroPlaza;
        this.coche = null;
        this.disponible = true;
        this.cochesAparcados = 0;
    }

    public int getNumeroPlaza() {
        return numeroPlaza;
    }

    public Coche getCoche() {
        return coche;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public int getCochesAparcados() {
        return cochesAparcados;
    }

    public void mostrarAtributos() {
        System.out.println("Numero de Plaza: " + numeroPlaza);
        System.out.println("Disponible: " + (disponible ? "Si" : "No"));
        if (coche != null) {
            coche.mostrarAtributos();
        } else {
            System.out.println("No hay coche aparcado.");
        }
        System.out.println("Total de coches que han aparcado: " + cochesAparcados);
    }

    public void aparcarCoche() {
        if (disponible) {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Ingrese matricula: ");
            String matricula = scanner.nextLine();
            System.out.print("Ingrese marca: ");
            String marca = scanner.nextLine();
            System.out.print("Ingrese modelo: ");
            String modelo = scanner.nextLine();
            this.coche = new Coche(matricula, marca, modelo);
            this.disponible = false;
            this.cochesAparcados++;
            System.out.println("EL COCHE SE HA APARCADO.");
        } else {
            System.out.println("PLAZA YA OCUPADA POR OTRO COCHE.");
        }
    }

    public void sacarCoche() {
        if (!disponible) {
            System.out.println("PLAZA LIBRE EL COCHE " + coche.getMatricula() + " HA SALIDO DE LA PLAZA.");
            this.coche = null;
            this.disponible = true;
        } else {
            System.out.println("ERROR, NO HAY COCHE EN LA PLAZA DE APARCAMIENTO. LA PLAZA ESTÁ LIBRE.");
        }
    }

    public void verCocheAparcado() {
        if (!disponible) {
            coche.mostrarAtributos();
        } else {
            System.out.println("LA PLAZA ESTA LIBRE.");
        }
    }
}

