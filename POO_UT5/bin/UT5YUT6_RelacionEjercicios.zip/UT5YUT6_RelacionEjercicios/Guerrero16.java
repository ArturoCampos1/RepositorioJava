package UT5YUT6_RelacionEjercicios;

public class Guerrero16 extends Personaje16 {
    private String arma;

    public Guerrero16(String nombre, String arma, int energia) {
        super(nombre, energia);
        this.arma = arma;
    }

    public String combatir(int energiaGastada) {
        if (energiaGastada > energia) {
            return "No tienes suficiente energía para el ataque.";
        }
        energia -= energiaGastada;
        return arma + " con fuerza de " + energiaGastada;
    }

    public String getArma() {
        return arma;
    }
}
