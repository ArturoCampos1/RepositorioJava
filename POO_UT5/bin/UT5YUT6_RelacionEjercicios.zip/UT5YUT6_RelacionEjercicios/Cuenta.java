package UT5YUT6_RelacionEjercicios;

public class Cuenta {
	
    private static long ultimoNumeroCuenta = 100000; 
    private long numCuenta;
	private String dni;
	private double saldo;
	private double interes;

	public Cuenta() {

	}

	public Cuenta(String dni, double saldo, double interes) {
        this.numCuenta = ++ultimoNumeroCuenta;
		this.dni = dni;
		this.saldo = saldo;
		this.interes = interes;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public double getInteres() {
		return interes;
	}

	public void setInteres(double interes) {
		this.interes = interes;
	}

	public void setNumCuenta(long numCuenta) {
		this.numCuenta = numCuenta;
	}

	public void actualizarSaldo() {
		double interesDiario = interes / 365;
        saldo += saldo * (interesDiario / 100);
		
	}
	
	public void ingresar(double ingreso) {
		saldo += ingreso;
	}
	
	public void retirar(double retiro) {
		saldo -= retiro;
	}
	
	public void mostrarDatos() {
        System.out.println("Número de Cuenta: " + numCuenta);
        System.out.println("DNI: " + dni);
        System.out.println("Saldo: " + saldo);
        System.out.println("Interés Anual: " + interes + "%");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Cuenta cuenta1 = new Cuenta("59292952J", 5000d, 10d);
		cuenta1.mostrarDatos();
		System.out.println();
		Cuenta cuenta2 = new Cuenta("64930573G", 2420d, 2d); //Prueba de bumCuenta (ascienden de forma correlativa)
		cuenta2.mostrarDatos();
		
		System.out.println("--------------------------------");
		//Prueba de ingreso y retiro
		
		cuenta2.ingresar(420.5);
		cuenta1.retirar(500);
		
		cuenta1.mostrarDatos();
		System.out.println();
		cuenta2.mostrarDatos();
		
		System.out.println("---------------------------------");
		
		//Actualizar saldo
		
		cuenta1.actualizarSaldo();
		cuenta1.mostrarDatos();

	}

}
