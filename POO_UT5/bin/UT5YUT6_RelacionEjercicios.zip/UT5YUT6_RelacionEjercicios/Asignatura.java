package UT5YUT6_RelacionEjercicios;

public class Asignatura {
	private String nombre;
	private int nota;

	public Asignatura(String nombre, int nota) {
		this.nombre = nombre;
		this.nota = nota;
	}

	public int getNota() {
		return nota;
	}

	public void setNota(int nota) {
		this.nota = nota;
	}

	public String correccion() {
		if (nota >= 5) {
			return "Aprobado";
		} else return "Suspenso";
	}
	
	public String mostrarAsignatura() {
		return nombre;
	}
	
	public static void main(String[] args) {
		
		Asignatura asignatura1 = new Asignatura("Programación", 6);
		
		asignatura1.setNota(2); //Pueba del set
		
		System.out.println(asignatura1.correccion()); //Prueba de el metodo aprobado/suspenso
		
		System.out.println(asignatura1.mostrarAsignatura()); //Muestra el nombre de la asignat.
	}
}
