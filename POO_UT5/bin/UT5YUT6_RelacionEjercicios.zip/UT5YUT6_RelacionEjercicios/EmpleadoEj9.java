package UT5YUT6_RelacionEjercicios;

public class EmpleadoEj9 {
	String nombre;
    int salario;
    Direccion direccion;

    public EmpleadoEj9(String nombre, int salario, Direccion direccion) {
        this.nombre = nombre;
        this.salario = salario;
        this.direccion = direccion;
    }

    public void mostrarDatos() {
        System.out.println("Nombre: " + nombre);
        System.out.println("Salario: " + salario);
        System.out.println("Dirección: ");
        System.out.println("Calle: " + direccion.calle);
        System.out.println("Número: " + direccion.numero);
        System.out.println("Piso: " + direccion.piso);
        System.out.println("Ciudad: " + direccion.ciudad);
        System.out.println();
    }
}
