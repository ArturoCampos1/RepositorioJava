package UT5YUT6_RelacionEjercicios;

public class TestPersonajes16 {
    public static void main(String[] args) {
        Guerrero16 guerrero = new Guerrero16("Conan", "Espada", 150);
        Mago16 mago = new Mago16("Merlín", "Hechizo de fuego");

        System.out.println(guerrero.getNombre() + " tiene " + guerrero.getEnergia() + " de energía.");
        System.out.println(mago.getNombre() + " tiene " + mago.getEnergia() + " de energía.");

        System.out.println("\n" + guerrero.getNombre() + " ataca con: " + guerrero.combatir(50));
        System.out.println(mago.getNombre() + " usa: " + mago.encantar());

        System.out.println("\nEnergía después de las acciones:");
        System.out.println(guerrero.getNombre() + " tiene " + guerrero.getEnergia() + " de energía.");
        System.out.println(mago.getNombre() + " tiene " + mago.getEnergia() + " de energía.");

        guerrero.alimentarse(30);
        mago.alimentarse(20);

        System.out.println("\nEnergía después de alimentarse:");
        System.out.println(guerrero.getNombre() + " tiene " + guerrero.getEnergia() + " de energía.");
        System.out.println(mago.getNombre() + " tiene " + mago.getEnergia() + " de energía.");
    }
}
