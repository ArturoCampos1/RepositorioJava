package UT5YUT6_RelacionEjercicios;

import java.util.Scanner;

public class CajeroEj15 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        CuentaEj15 cuenta = null;
        int opcion;

        do {
            System.out.println("\n----- MENÚ -----");
            System.out.println("1.- Crear cuenta vacía.");
            System.out.println("2.- Crear cuenta con saldo inicial.");
            System.out.println("3.- Ingresar dinero.");
            System.out.println("4.- Sacar dinero.");
            System.out.println("5.- Ver saldo.");
            System.out.println("6.- Salir.");
            System.out.print("Seleccione una opción: ");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1:
                    cuenta = new CuentaEj15();
                    System.out.println("Cuenta creada con saldo 0.");
                    break;
                case 2:
                    System.out.print("Ingrese el saldo inicial: ");
                    float saldoInicial = sc.nextFloat();
                    cuenta = new CuentaEj15(saldoInicial);
                    System.out.println("Cuenta creada con saldo inicial de " + saldoInicial + ".");
                    break;
                case 3:
                    if (cuenta != null) {
                        System.out.print("Ingrese la cantidad a depositar: ");
                        float cantidadIngreso = sc.nextFloat();
                        cuenta.ingresar(cantidadIngreso);
                        System.out.println("Se han ingresado " + cantidadIngreso + " en la cuenta.");
                    } else {
                        System.out.println("Primero debe crear una cuenta (opción 1 o 2).");
                    }
                    break;
                case 4:
                    if (cuenta != null) {
                        System.out.print("Ingrese la cantidad a extraer: ");
                        float cantidadExtraccion = sc.nextFloat();
                        cuenta.extraer(cantidadExtraccion);
                        System.out.println("Se han extraído " + cantidadExtraccion + " de la cuenta.");
                    } else {
                        System.out.println("Primero debe crear una cuenta (opción 1 o 2).");
                    }
                    break;
                case 5:
                    if (cuenta != null) {
                        System.out.println("El saldo actual es: " + cuenta.getSaldo());
                    } else {
                        System.out.println("Primero debe crear una cuenta (opción 1 o 2).");
                    }
                    break;
                case 6:
                    System.out.println("Saliendo del programa...");
                    break;
                default:
                    System.out.println("Opción inválida, intente de nuevo.");
            }
        } while (opcion != 6);

        sc.close();
    }
}
