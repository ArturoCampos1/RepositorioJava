package UT5YUT6_RelacionEjercicios;

public class Marte {
    public static void main(String[] args) {
        Marciano et1 = new Marciano("ET1");
        Marciano et2 = new Marciano("ET2");
        Marciano et3 = new Marciano("ET3");
        
        et2.muere();
        
        Marciano et4 = new Marciano("ET4");
        
        et2.muere();
        
        System.out.println("\nSituación final de los marcianos:");
        System.out.println(et1);
        System.out.println(et2);
        System.out.println(et3);
        System.out.println(et4);
        
        System.out.println("Marcianos vivos: " + Marciano.cuentaMarcianos());
    }
}
